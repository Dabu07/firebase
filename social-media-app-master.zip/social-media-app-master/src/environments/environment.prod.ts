export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyCY7DMW4LN2izvO0ugTGFy4RShBY8RcDcs',
    authDomain: 'angular-social-media.firebaseapp.com',
    databaseURL: 'https://angular-social-media.firebaseio.com',
    projectId: 'angular-social-media',
    storageBucket: 'angular-social-media.appspot.com',
    messagingSenderId: '720031157390',
    appId: '1:720031157390:web:4ad15bc83d9f7479cbcddf',
    measurementId: 'G-Y009ZNJFER',
  },
};
